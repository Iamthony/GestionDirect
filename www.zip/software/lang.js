// Language array initialization
var translations = new Object();
translations['fr'] = new Array();
translations['en'] = new Array();
translations['es'] = new Array();
translations['zh-tw'] = new Array();
translations['zh-cn'] = new Array();
translations['it'] = new Array();
translations['pt-br'] = new Array();

// English
translations['en']['Invalid credentials'] = 'Invalid credentials';
translations['en']['Too many failed attempts.'] = 'Too many failed attempts.';
translations['en']['Please retry later.'] = 'Please retry later.';

translations['en']['Protect your account with 2-step verification'] = 'Protect your account with 2-step verification';
translations['en']['Display the verification code using an authentication app'] = 'Display the verification code using an authentication app';
translations['en']['Open the authenticator app on your mobile phone.'] = 'Open the authenticator app on your mobile phone.';
translations['en']['Scan the QR code displayed below:'] = 'Scan the QR code displayed below:';
translations['en']['Or receive your verification code via SMS'] = 'Or receive your verification code via SMS';
translations['en']['Type your phone number below, using the international phone numbers format (e.g. +14155552671):'] = 'Type your phone number below, using the international phone numbers format (e.g. +14155552671):';
translations['en']['Click Receive SMS button to register your phone number and receive your verification code.'] = 'Click Receive SMS button to register your phone number and receive your verification code.';
translations['en']['Receive SMS'] = 'Receive SMS';
translations['en']['Validate your verification code'] = 'Validate your verification code';
translations['en']['Validate'] = 'Validate';
translations['en']['Please enter a valid confirmation code.'] = 'Please enter a valid confirmation code.';
translations['en']['An error occured while validating your 2-step verification code. Please retry or contact your administrator.'] = 'An error occured while validating your 2-step verification code. Please retry or contact your administrator.';
translations['en']['You are all set. From now on, you will use your authenticator app or receive your verification code by SMS to sign in your remote session.'] = 'You are all set. From now on, you will use your authenticator app or receive your verification code by SMS to sign in your remote session.';
translations['en']['Failed to send SMS verification code. Please ensure that your configured phone number is a valid phone number following E.164 format for international phone numbers (e.g. +14155552671). Otherwise, please contact your administrator.'] = 'Failed to send SMS verification code. Please ensure that your configured phone number is a valid phone number following E.164 format for international phone numbers (e.g. +14155552671). Otherwise, please contact your administrator.';
translations['en']['No QR code was generated! Please enter your credentials on the logon page.'] = 'No QR code was generated! Please enter your credentials on the logon page.';
translations['en']['Secret key:'] = 'Secret key:';

translations['en']['Reset your Windows password'] = 'Reset your Windows password';
translations['en']['Your username'] = 'Your username';
translations['en']['Your old password'] = 'Your old password';
translations['en']['Your new password'] = 'Your new password';
translations['en']['Confirm your new password'] = 'Confirm your new password';

translations['en']['Expiration password reminder'] = 'Expiration password reminder';
translations['en']['Would you like to change it now?'] = 'Would you like to change it now?';
translations['en']['Yes'] = 'Yes';
translations['en']['No'] = 'No';

translations['en']['Your windows password has expired!'] = 'Your windows password has expired!';
translations['en']['Your windows password expires in %DAYS% days.'] = 'Your windows password expires in %DAYS% days.';
translations['en']['A reset password request is currently being processed, please wait.'] = 'A reset password request is currently being processed, please wait.';
translations['en']['Error: username field is empty!'] = 'Error: username field is empty!';
translations['en']['Error: old password field is empty!'] = 'Error: old password field is empty!';
translations['en']['Error: new password field is empty!'] = 'Error: new password field is empty!';
translations['en']['Error: old password and new password are identical!'] = 'Error: old password and new password are identical!';
translations['en']['Error: confirm new password field is empty!'] = 'Error: confirm new password field is empty!';
translations['en']['Error: new password and confirmed one don\'t match!'] = 'Error: new password and confirmed one don\'t match!';
translations['en']['Error: cannot parse full username due to invalid character'] = 'Error: cannot parse full username due to invalid character';
translations['en']['Error: invalid character in username provided'] = 'Error: invalid character in username provided';

translations['en']['Error: The user does not have access to the requested information.'] = 'Error: The user does not have access to the requested information.';
translations['en']['Error: The user has entered an invalid password.'] = 'Error: The user has entered an invalid password.';
translations['en']['Error: The computer name is invalid.'] = 'Error: The computer name is invalid.';
translations['en']['Error: The operation is allowed only on the primary domain controller of the domain.'] = 'Error: The operation is allowed only on the primary domain controller of the domain.';
translations['en']['Error: The user name could not be found.'] = 'Error: The user name could not be found.';
translations['en']['Error: The password doesn\'t meet with the current password policy requirement.'] = 'Error: The password doesn\'t meet with the current password policy requirement.';
translations['en']['Error: Cannot access to specified domain'] = 'Error: Cannot access to specified domain';
translations['en']['An internal error occured'] = 'An internal error occured';

translations['en']['Windows password changed! Please retry connecting with your new password.'] = 'Windows password changed! Please retry connecting with your new password.';

translations['en']['Admin not allowed to connect via the web portal'] = 'Admin not allowed to connect via the web portal';

// French
translations['fr']['Invalid credentials'] = 'Identifiants non valides';
translations['fr']['Too many failed attempts.'] = 'Trop de tentatives de connexion échouées.';
translations['fr']['Please retry later.'] = 'Veuillez réessayer plus tard.';

translations['fr']['Protect your account with 2-step verification'] = 'Protégez votre compte avec l\'authentification double facteur';
translations['fr']['Display the verification code using an authentication app'] = 'Affichez votre code de vérification en utilisant votre application d\'authentification 2FA';
translations['fr']['Open the authenticator app on your mobile phone.'] = 'Ouvrez votre application d\'authentification sur votre téléphone portable.';
translations['fr']['Scan the QR code displayed below:'] = 'Scannez le QR code affiché ci-dessous:';
translations['fr']['Or receive your verification code via SMS'] = 'Ou recevez votre code de vérification par SMS';
translations['fr']['Type your phone number below, using the international phone numbers format (e.g. +14155552671):'] = 'Renseignez votre numéro de téléphone ci-dessous, en utilisant le format international (ex: +14155552671):';
translations['fr']['Click Receive SMS button to register your phone number and receive your verification code.'] = 'Cliquez sur le bouton Recevoir SMS pour enregistrer votre numéro de téléphone, et recevoir votre code de vérification.';
translations['fr']['Receive SMS'] = 'Recevoir SMS';
translations['fr']['Validate your verification code'] = 'Validez votre code de vérification';
translations['fr']['Validate'] = 'Valider';
translations['fr']['Please enter a valid confirmation code.'] = 'Veuillez rentrer un code de vérification valide';
translations['fr']['An error occured while validating your 2-step verification code. Please retry or contact your administrator.'] = 'Une erreur s\'est produite durant la validation de votre authentification double facteur. Veuillez réessayer ou contacter un administrateur.';
translations['fr']['You are all set. From now on, you will use your authenticator app or receive your verification code by SMS to sign in your remote session.'] = 'Activation réussie. Vous pouvez désormais utiliser votre application d\'authentification 2FA ou recevoir votre code de vérification par SMS pour vous connecter à distance';
translations['fr']['Failed to send SMS verification code. Please ensure that your configured phone number is a valid phone number following E.164 format for international phone numbers (e.g. +14155552671). Otherwise, please contact your administrator.'] = 'Envoi de code de vérification par SMS échoué. Veuillez vous assurer que votre numéro de téléphone respecte le format de numéro international (ex: +14155552671). Sinon, contactez un administrateur. ';
translations['fr']['No QR code was generated! Please enter your credentials on the logon page.'] = 'Aucun QR code généré ! Veuillez rentrer vos identififiants sur la page de connexion.';
translations['fr']['Secret key:'] = 'Clef secrète :';

translations['fr']['Reset your Windows password'] = 'Réinitialiser votre mot de passe Windows';
translations['fr']['Your username'] = 'Votre nom d\'utilisateur';
translations['fr']['Your old password'] = 'Votre ancien mot de passe';
translations['fr']['Your new password'] = 'Votre nouveau mot de passe';
translations['fr']['Confirm your new password'] = 'Confirmez votre nouveau mot de passe';

translations['fr']['Expiration password reminder'] = 'Rappel d\'expiration de votre mot de passe';
translations['fr']['Would you like to change it now?'] = 'Souhaitez-vous le changer maintenant ?';
translations['fr']['Yes'] = 'Oui';
translations['fr']['No'] = 'Non';

translations['fr']['Your windows password has expired!'] = 'Votre mot de passe windows a expiré !';
translations['fr']['Your windows password expires in %DAYS% days.'] = 'Votre mot de passe windows expire dans %DAYS% jours.';
translations['fr']['A reset password request is currently being processed, please wait.'] = 'Une requête de changement de mot de passe est en cours, merci de patienter.';
translations['fr']['Error: username field is empty!'] = 'Erreur : le nom d\'utilisateur est vide !';
translations['fr']['Error: old password field is empty!'] = 'Erreur : l\'ancien mot de passe est vide !';
translations['fr']['Error: new password field is empty!'] = 'Erreur : le nouveau mot de passe est vide !';
translations['fr']['Error: old password and new password are identical!'] = 'Erreur : l\'ancien mot de passe est identique au nouveau !';
translations['fr']['Error: confirm new password field is empty!'] = 'Erreur : le mot de passe confirmé est vide !';
translations['fr']['Error: new password and confirmed one don\'t match!'] = 'Erreur : le nouveau mot de passe et sa confirmation sont différents !';
translations['fr']['Error: cannot parse full username due to invalid character'] = 'Erreur : impossible d\'analyser le nom d\'utilisateur pour cause de caractères invalides';
translations['fr']['Error: invalid character in username provided'] = 'Erreur : caractère non valide utilisé dans le nom d\'utilisateur';
translations['fr']['Error: The user does not have access to the requested information.'] = 'Erreur : l\'utilisateur n\'a pas accès à l\'information demandée';
translations['fr']['Error: The user has entered an invalid password.'] = 'Erreur : l\'utilisateur a entré un mot de passe non valide.';
translations['fr']['Error: The computer name is invalid.'] = 'Error: The computer name is invalid.';
translations['fr']['Error: The operation is allowed only on the primary domain controller of the domain.'] = 'Erreur : cette opération n\'est autorisée que sur le contrôleur du domaine';
translations['fr']['Error: The user name could not be found.'] = 'Erreur : le nom d\'utilisateur est introuvable';
translations['fr']['Error: The password doesn\'t meet with the current password policy requirement.'] = 'Erreur : le mot de passe ne respecte pas les règles de complexité du mot de passe instaurées par le serveur';
translations['fr']['Error: Cannot access to specified domain'] = 'Error: Impossible d\'accéder au domain spécifié';
translations['fr']['An internal error occured'] = 'Une erreur interne s\'est produite';

translations['fr']['Windows password changed! Please retry connecting with your new password.'] = 'Mot de passe Windows modifié ! Veuillez maintenant réessayer de vous connecter avec votre nouveau mot de passe.';

translations['fr']['Admin not allowed to connect via the web portal'] = 'Connection depuis le portail web non autorisé pour les administrateurs';

// Castellano
translations['es']['Invalid credentials'] = 'Credenciales inválidas';
translations['es']['Too many failed attempts.'] = 'Demasiados intentos fallidos.';
translations['es']['Please retry later.'] = 'Por favor intente más tarde.';

translations['es']['Protect your account with 2-step verification'] = 'Proteja su cuenta con la verificación de 2 pasos';
translations['es']['Display the verification code using an authentication app'] = 'Muestre el código de verificación usando una app de autenticación';
translations['es']['Open the authenticator app on your mobile phone.'] = 'Abrir la app de autenticación en su teléfono celular.';
translations['es']['Scan the QR code displayed below:'] = 'Scanear el código QR que se muestra debajo:';
translations['es']['Or receive your verification code via SMS'] = 'O recibir el código de verificación vía SMS';
translations['es']['Type your phone number below, using the international phone numbers format (e.g. +14155552671):'] = 'Escriba su número de teléfono debajo, usando el formato internacional (ej: +14155552671):';
translations['es']['Click Receive SMS button to register your phone number and receive your verification code.'] = 'Click en el botón Recibir SMS para registrar su número de teléfono y recivir su código de verificación.';
translations['es']['Receive SMS'] = 'Recibir SMS';
translations['es']['Validate your verification code'] = 'Validar su código de verificación';
translations['es']['Validate'] = 'Validar';
translations['es']['Please enter a valid confirmation code.'] = 'Por favor ingrese un código de verificación válido.';
translations['es']['An error occured while validating your 2-step verification code. Please retry or contact your administrator.'] = 'Ocurrió un error mientras se validaba su código de verificación en 2 pasos. Por favor reintente o contacte a su administrador.';
translations['es']['You are all set. From now on, you will use your authenticator app or receive your verification code by SMS to sign in your remote session.'] = 'Todo está listo. De ahora en adelante, Ud. puede usar su app de autenticación o recibir su código de verificación por SMS para ingresar en su sesióm remota.';
translations['es']['Failed to send SMS verification code. Please ensure that your configured phone number is a valid phone number following E.164 format for international phone numbers (e.g. +14155552671). Otherwise, please contact your administrator.'] = 'Error al enviar el código de verificación por SMS. Por favor, asegúrese de su número de teléfono configurado es un número válido que sigue la normativa E.164 de formato para números de telefono internacionales (ej: +14155552671). Si no, por favor contacte al administrador.';
translations['es']['Secret key:'] = 'Secret key:';

// Taiwan
translations['zh-tw']['Invalid credentials'] = '輸入的認證無效';
translations['zh-tw']['Too many failed attempts.'] = '太多失敗嘗試。';
translations['zh-tw']['Please retry later.'] = '請稍後重試。';

translations['zh-tw']['Protect your account with 2-step verification'] = '使用兩步驟驗證保護您的帳戶';
translations['zh-tw']['Display the verification code using an authentication app'] = '使用驗證器 App 顯示驗證碼';
translations['zh-tw']['Open the authenticator app on your mobile phone.'] = '在您的手機開啟驗證器 App。';
translations['zh-tw']['Scan the QR code displayed below:'] = '掃描以下顯示的二維碼:';
translations['zh-tw']['Or receive your verification code via SMS'] = '或透過簡訊接收您的驗證碼';
translations['zh-tw']['Type your phone number below, using the international phone numbers format (e.g. +14155552671):'] = '在下方以國際電話號碼格式輸入您的電話號碼 (例如 +886123456789):';
translations['zh-tw']['Click Receive SMS button to register your phone number and receive your verification code.'] = '按一下「接收簡訊」按鈕以註冊您的電話號碼並收到您的驗證碼。';
translations['zh-tw']['Receive SMS'] = '接收簡訊';
translations['zh-tw']['Validate your verification code'] = '請輸入您的驗證碼';
translations['zh-tw']['Validate'] = '驗證';
translations['zh-tw']['Please enter a valid confirmation code.'] = '請輸入有效的驗證碼';
translations['zh-tw']['An error occured while validating your 2-step verification code. Please retry or contact your administrator.'] = '驗證您的兩步驟驗證碼時發生錯誤。 請重試或聯絡您的系統管理員。';
translations['zh-tw']['You are all set. From now on, you will use your authenticator app or receive your verification code by SMS to sign in your remote session.'] = '設定完成，從現在開始，您將使用驗證器 App 或透過簡訊接收驗證碼以登入遠端工作階段。';
translations['zh-tw']['Failed to send SMS verification code. Please ensure that your configured phone number is a valid phone number following E.164 format for international phone numbers (e.g. +14155552671). Otherwise, please contact your administrator.'] = '傳送簡訊驗證碼失敗。 請確認您設定的電話號碼是有效的，根據國際電話號碼的 E.164 格式 (例如 +886123456789)。 否則，請聯絡您的系統管理員。';
translations['zh-tw']['No QR code was generated! Please enter your credentials on the logon page.'] = '沒有產生二維碼! 請在登入頁面輸入您的認證。';
translations['zh-tw']['Secret key:'] = 'Secret key:';

translations['zh-tw']['Reset your Windows password'] = '重設您的 Windows 密碼';
translations['zh-tw']['Your username'] = '您的使用者名稱';
translations['zh-tw']['Your old password'] = '您的舊密碼';
translations['zh-tw']['Your new password'] = '您的新密碼';
translations['zh-tw']['Confirm your new password'] = '確認您的新密碼';

translations['zh-tw']['Expiration password reminder'] = '過期密碼提醒';
translations['zh-tw']['Would you like to change it now?'] = '您希望立即變更嗎?';
translations['zh-tw']['Yes'] = '是';
translations['zh-tw']['No'] = '否';

translations['zh-tw']['Your windows password has expired!'] = '您的 Windows 密碼已過期!';
translations['zh-tw']['Your windows password expires in %DAYS% days.'] = '您的 Windows 密碼在 %DAYS% 天內過期。';
translations['zh-tw']['A reset password request is currently being processed, please wait.'] = '重設密碼需求目前正在處理中，請稍候。';
translations['zh-tw']['Error: username field is empty!'] = '錯誤: 使用者名稱欄位為空!';
translations['zh-tw']['Error: old password field is empty!'] = '錯誤: 舊密碼欄位為空!';
translations['zh-tw']['Error: new password field is empty!'] = '錯誤: 新密碼欄位為空!';
translations['zh-tw']['Error: old password and new password are identical!'] = '錯誤: 舊密碼和新密碼完全一樣!';
translations['zh-tw']['Error: confirm new password field is empty!'] = '錯誤: 確認新密碼欄位為空!';
translations['zh-tw']['Error: new password and confirmed one don\'t match!'] = '錯誤: 新密碼和確認新密碼不相符!';
translations['zh-tw']['Error: cannot parse full username due to invalid character'] = '錯誤: 無法分析完整使用者名稱，因為無效字元';
translations['zh-tw']['Error: invalid character in username provided'] = '錯誤: 無效的字元在提供的使用者名稱';

translations['zh-tw']['Error: The user does not have access to the requested information.'] = '錯誤: 使用者沒有權限存取請求的資訊。';
translations['zh-tw']['Error: The user has entered an invalid password.'] = '錯誤: 使用者輸入的密碼無效。';
translations['zh-tw']['Error: The computer name is invalid.'] = '錯誤: 電腦名稱無效。';
translations['zh-tw']['Error: The operation is allowed only on the primary domain controller of the domain.'] = '錯誤: 操作只允許在網域的主網域控制站。';
translations['zh-tw']['Error: The user name could not be found.'] = '錯誤: 使用者名稱找不到。';
translations['zh-tw']['Error: The password doesn\'t meet with the current password policy requirement.'] = '錯誤: 密碼不符合目前的密碼原則需求。';
translations['zh-tw']['Error: Cannot access to specified domain'] = '錯誤: 無法存取指定網域';
translations['zh-tw']['An internal error occured'] = '發生內部錯誤';

translations['zh-tw']['Windows password changed! Please retry connecting with your new password.'] = 'Windows 密碼已變更! 請使用新密碼重試連線。';

translations['zh-tw']['Admin not allowed to connect via the web portal'] = '管理員不允許透過網頁入口連線';

// China
translations['zh-cn']['Invalid credentials'] = '输入的凭据无效';
translations['zh-cn']['Too many failed attempts.'] = '太多失败尝试。';
translations['zh-cn']['Please retry later.'] = '请稍后再试。';

translations['zh-cn']['Protect your account with 2-step verification'] = '使用两步骤验证保护您的帐户';
translations['zh-cn']['Display the verification code using an authentication app'] = '使用验证器 App 显示验证码';
translations['zh-cn']['Open the authenticator app on your mobile phone.'] = '在您的手机打开验证器 App。';
translations['zh-cn']['Scan the QR code displayed below:'] = '扫描以下显示的二维码:';
translations['zh-cn']['Or receive your verification code via SMS'] = '或透过短信接收您的验证码';
translations['zh-cn']['Type your phone number below, using the international phone numbers format (e.g. +14155552671):'] = '在下方以国际电话号码格式输入您的电话号码 (例如 +86123456789):';
translations['zh-cn']['Click Receive SMS button to register your phone number and receive your verification code.'] = '按一下「接收短信」按钮以登录您的电话号码并收到您的验证码。';
translations['zh-cn']['Receive SMS'] = '接收短信';
translations['zh-cn']['Validate your verification code'] = '请输入您的验证码';
translations['zh-cn']['Validate'] = '验证';
translations['zh-cn']['Please enter a valid confirmation code.'] = '请输入有效的验证码';
translations['zh-cn']['An error occured while validating your 2-step verification code. Please retry or contact your administrator.'] = '验证您的两步骤验证码时出错。 请再试或联系系统管理员。';
translations['zh-cn']['You are all set. From now on, you will use your authenticator app or receive your verification code by SMS to sign in your remote session.'] = '设置完成，从现在开始，您将使用您將使用验证器 App 或透过短信接收验证码来登录远程会话。';
translations['zh-cn']['Failed to send SMS verification code. Please ensure that your configured phone number is a valid phone number following E.164 format for international phone numbers (e.g. +14155552671). Otherwise, please contact your administrator.'] = '发送短信验证码失败。 请确认您设置的电话号码是有效的，根据国际电话号码的 E.164 格式 (例如 +886123456789)。 否则，请联系您的系统管理员。';
translations['zh-cn']['No QR code was generated! Please enter your credentials on the logon page.'] = '没有生成二维码! 请在登录页面输入您的凭据。';
translations['zh-cn']['Secret key:'] = '密钥:';

translations['zh-cn']['Reset your Windows password'] = '重置您的 Windows 密码';
translations['zh-cn']['Your username'] = '您的用户名';
translations['zh-cn']['Your old password'] = '您的旧密码';
translations['zh-cn']['Your new password'] = '您的新密码';
translations['zh-cn']['Confirm your new password'] = '确认您的新密码';

translations['zh-cn']['Expiration password reminder'] = '过期密码提醒';
translations['zh-cn']['Would you like to change it now?'] = '您希望立即改变吗?';
translations['zh-cn']['Yes'] = '是';
translations['zh-cn']['No'] = '否';

translations['zh-cn']['Your windows password has expired!'] = '您的 Windows 密码已过期!';
translations['zh-cn']['Your windows password expires in %DAYS% days.'] = '您的 Windows 密码在 %DAYS% 天内过期。';
translations['zh-cn']['A reset password request is currently being processed, please wait.'] = '当前正在处理重置密码请求，请稍候。';
translations['zh-cn']['Error: username field is empty!'] = '出错: 用户栏为空!';
translations['zh-cn']['Error: old password field is empty!'] = '出错: 旧密码栏为空!';
translations['zh-cn']['Error: new password field is empty!'] = '出错: 新密码栏为空!';
translations['zh-cn']['Error: old password and new password are identical!'] = '出错: 旧密码和新密码完全一样!';
translations['zh-cn']['Error: confirm new password field is empty!'] = '出错: 确认新密码栏为空!';
translations['zh-cn']['Error: new password and confirmed one don\'t match!'] = '出错: 旧新密码和确认密码不匹配!';
translations['zh-cn']['Error: cannot parse full username due to invalid character'] = '出错: 无法分析用户名，因为无效字符';
translations['zh-cn']['Error: invalid character in username provided'] = '出错: 无效的字符在提供的用户名';

translations['zh-cn']['Error: The user does not have access to the requested information.'] = '出错: 用户没有权利访问请求的信息。';
translations['zh-cn']['Error: The user has entered an invalid password.'] = '出错: 用户输入无效的密码。';
translations['zh-cn']['Error: The computer name is invalid.'] = '出错: 电脑名无效。';
translations['zh-cn']['Error: The operation is allowed only on the primary domain controller of the domain.'] = '出错: 操作只允许在域的主域控制站。';
translations['zh-cn']['Error: The user name could not be found.'] = '出错: 找不到用户名。';
translations['zh-cn']['Error: The password doesn\'t meet with the current password policy requirement.'] = '出错: 密码与当前密码政策需求不匹配。';
translations['zh-cn']['Error: Cannot access to specified domain'] = '出错: 无法访问指定的域';
translations['zh-cn']['An internal error occured'] = '发生内部错误';

translations['zh-cn']['Windows password changed! Please retry connecting with your new password.'] = 'Windows 密码已变更! 请使用您的新密码再试连接。';

translations['zh-cn']['Admin not allowed to connect via the web portal'] = '管理员不允许透过网页入口连接';

// Italian
translations['it']['Invalid credentials'] = 'Credenziali non valide';
translations['it']['Too many failed attempts.'] = 'Troppi tentativi falliti.';
translations['it']['Please retry later.'] = 'Riprovare più tardi.';

translations['it']['Protect your account with 2-step verification'] = 'Proteggi il tuo account con la verifica in 2 passaggi';
translations['it']['Display the verification code using an authentication app'] = 'Visualizzare il codice QR utilizzando un\'app di autenticazione.';
translations['it']['Open the authenticator app on your mobile phone.'] = 'Apra l\'applicazione di autenticazione sul suo telefono cellulare.';
translations['it']['Scan the QR code displayed below:'] = 'Scannerizza il codice QR visualizzato qui sotto:';
translations['it']['Or receive your verification code via SMS'] = 'Oppure ricevi il tuo codice di verifica via SMS';
translations['it']['Type your phone number below, using the international phone numbers format (e.g. +14155552671):'] = 'Scrivi il tuo numero di telefono qui sotto, usando il formato dei numeri di telefono internazionali (ad esempio +14155552671):';
translations['it']['Click Receive SMS button to register your phone number and receive your verification code.'] = 'Clicca su Ricevi SMS per registrare il tuo numero di telefono e ricevere il tuo codice di verifica.';
translations['it']['Receive SMS'] = 'Ricevi SMS';
translations['it']['Validate your verification code'] = 'Convalida codice di verifica';
translations['it']['Validate'] = 'Convalida';
translations['it']['Please enter a valid confirmation code.'] = 'Inserire codice di conferma valido.';
translations['it']['An error occured while validating your 2-step verification code. Please retry or contact your administrator.'] = 'Si è verificato un errore durante la convalida del tuo codice di verifica in 2 passaggi. Riprova o contatta il tuo amministratore.';
translations['it']['You are all set. From now on, you will use your authenticator app or receive your verification code by SMS to sign in your remote session.'] = 'Tutto è configurato. D\'ora in poi, userai la tua app authenticator o riceverai il tuo codice di verifica via SMS per accedere alla tua sessione remota.';
translations['it']['Failed to send SMS verification code. Please ensure that your configured phone number is a valid phone number following E.164 format for international phone numbers (e.g. +14155552671). Otherwise, please contact your administrator.'] = 'Impossibile inviare il codice di verifica SMS. Assicurati che il numero di telefono configurato sia un numero di telefono valido secondo il formato E.164 per i numeri di telefono internazionali (ad esempio +14155552671). Altrimenti, contatta il tuo amministratore.';
translations['it']['No QR code was generated! Please enter your credentials on the logon page.'] = 'Non è stato generato alcun codice QR! Inserisci le tue credenziali nella pagina di accesso.';
translations['it']['Secret key:'] = 'Chiave segreta:';

translations['it']['Reset your Windows password'] = 'Resetta password di Windows';
translations['it']['Your username'] = 'Nome utente';
translations['it']['Your old password'] = 'Vecchio password';
translations['it']['Your new password'] = 'Nuovo password';
translations['it']['Confirm your new password'] = 'Conferma nuova password';

translations['it']['Expiration password reminder'] = 'Promemoria scadenza password';
translations['it']['Would you like to change it now?'] = 'Vuoi cambiarlo ora?';
translations['it']['Yes'] = 'Si';
translations['it']['No'] = 'No';

translations['it']['Your windows password has expired!'] = 'La tua password di windows è scaduta!';
translations['it']['Your windows password expires in %DAYS% days.'] = 'La tua password di windows scade tra %DAYS% giorni.';
translations['it']['A reset password request is currently being processed, please wait.'] = 'Una richiesta di reset password è in corso, prego attendere.';
translations['it']['Error: username field is empty!'] = 'Errore: il campo username è vuoto!';
translations['it']['Error: old password field is empty!'] = 'Errore: il campo vecchia password è vuoto!';
translations['it']['Error: new password field is empty!'] = 'Errore: il campo nuova password è vuoto!';
translations['it']['Error: old password and new password are identical!'] = 'Errore: la vecchia password e la nuova password sono identiche!';
translations['it']['Error: confirm new password field is empty!'] = 'Errore: il campo conferma nuova password è vuoto!';
translations['it']['Error: new password and confirmed one don\'t match!'] = 'Errore: la nuova password e quella confermata non corrispondono!';
translations['it']['Error: cannot parse full username due to invalid character'] = 'Errore: impossibile leggere il nome utente completo a causa di un carattere non valido';
translations['it']['Error: invalid character in username provided'] = 'Errore: carattere non valido nel nome utente fornito';

translations['it']['Error: The user does not have access to the requested information.'] = 'Errore: L\'utente non ha accesso alle informazioni richieste.';
translations['it']['Error: The user has entered an invalid password.'] = 'Errore: L\'utente ha inserito una password non valida.';
translations['it']['Error: The computer name is invalid.'] = 'Errore: Nome computer non valido.';
translations['it']['Error: The operation is allowed only on the primary domain controller of the domain.'] = 'Errore: L\'operazione è consentita solo sul controller di dominio.';
translations['it']['Error: The user name could not be found.'] = 'Errore: Impossibile trovare il nome dell\'utente.';
translations['it']['Error: The password doesn\'t meet with the current password policy requirement.'] = 'Errore:La password non soddisfa i requisiti dell\'attuale politica delle password.';
translations['it']['Error: Cannot access to specified domain'] = 'Errore: Impossibile accedere al dominio specificato';
translations['it']['An internal error occured'] = 'Si è verificato un errore interno';

translations['it']['Windows password changed! Please retry connecting with your new password.'] = 'La password di Windows è cambiata! Per favore, riprova a connetterti con la tua nuova password.';

translations['it']['Admin not allowed to connect via the web portal'] = 'Admin non autorizzato a connettersi tramite il portale web';

// Portuguese (Brazil)
translations['pt-br']['Invalid credentials'] = 'Credenciais inválidas';
translations['pt-br']['Too many failed attempts.'] = 'Muitas tentativas falhas.';
translations['pt-br']['Please retry later.'] = 'Tente novamente mais tarde.';

translations['pt-br']['Protect your account with 2-step verification'] = 'Proteja sua conta com a verificação em duas etapas';
translations['pt-br']['Display the verification code using an authentication app'] = 'Exibir o código de verificação usando um aplicativo de autenticação';
translations['pt-br']['Open the authenticator app on your mobile phone.'] = 'Abra o aplicativo autenticador no seu celular.';
translations['pt-br']['Scan the QR code displayed below:'] = 'Leia o código QR exibido abaixo:';
translations['pt-br']['Or receive your verification code via SMS'] = 'Ou receba seu código de verificação por SMS';
translations['pt-br']['Type your phone number below, using the international phone numbers format (e.g. +14155552671):'] = 'Digite seu número de telefone abaixo, usando o formato de números de telefone internacionais (por exemplo, +14155552671):';
translations['pt-br']['Click Receive SMS button to register your phone number and receive your verification code.'] = 'Clique no botão Receber SMS para registrar seu número de telefone e receber seu código de verificação.';
translations['pt-br']['Receive SMS'] = 'Receber SMS';
translations['pt-br']['Validate your verification code'] = 'Valide o seu código de verificação';
translations['pt-br']['Validate'] = 'Validar';
translations['pt-br']['Please enter a valid confirmation code.'] = 'Por favor, insira um código de confirmação válido.';
translations['pt-br']['An error occured while validating your 2-step verification code. Please retry or contact your administrator.'] = 'Ocorreu um erro ao validar seu código de verificação em duas etapas. Tente novamente ou entre em contato com o administrador.';
translations['pt-br']['You are all set. From now on, you will use your authenticator app or receive your verification code by SMS to sign in your remote session.'] = 'Estás pronto. A partir de agora, você usará seu aplicativo autenticador ou receberá seu código de verificação por SMS para fazer login em sua sessão remota.';
translations['pt-br']['Failed to send SMS verification code. Please ensure that your configured phone number is a valid phone number following E.164 format for international phone numbers (e.g. +14155552671). Otherwise, please contact your administrator.'] = 'Falha ao enviar código de verificação SMS. Certifique-se de que o seu número de telefone configurado seja um número de telefone válido seguindo o formato E.164 para números de telefone internacionais (por exemplo, +14155552671). Caso contrário, entre em contato com o seu administrador.';
translations['pt-br']['No QR code was generated! Please enter your credentials on the logon page.'] = 'Nenhum código QR foi gerado! Por favor, insira suas credenciais na página de logon.';
translations['pt-br']['Secret key:'] = 'Chave secreta:';

translations['pt-br']['Reset your Windows password'] = 'Redefina sua senha do Windows';
translations['pt-br']['Your username'] = 'Seu nome de usuário';
translations['pt-br']['Your old password'] = 'Sua senha antiga';
translations['pt-br']['Your new password'] = 'Sua nova senha';
translations['pt-br']['Confirm your new password'] = 'Confirme sua nova senha';

translations['pt-br']['Expiration password reminder'] = 'Lembrete de senha de expiração';
translations['pt-br']['Would you like to change it now?'] = 'Você gostaria de mudar isso agora?';
translations['pt-br']['Yes'] = 'Sim';
translations['pt-br']['No'] = 'Não';

translations['pt-br']['Your windows password has expired!'] = 'Sua senha do Windows expirou!';
translations['pt-br']['Your windows password expires in %DAYS% days.'] = 'Sua senha do Windows expira em% DAYS% dias.';
translations['pt-br']['A reset password request is currently being processed, please wait.'] = 'Uma solicitação de redefinição de senha está sendo processada. Aguarde.';
translations['pt-br']['Error: username field is empty!'] = 'Erro: o campo do nome de usuário está vazio!';
translations['pt-br']['Error: old password field is empty!'] = 'Erro: o campo da senha antiga está vazio!';
translations['pt-br']['Error: new password field is empty!'] = 'Erro: o campo da nova senha está vazio!';
translations['pt-br']['Error: old password and new password are identical!'] = 'Erro: a senha antiga e a nova são idênticas!';
translations['pt-br']['Error: confirm new password field is empty!'] = 'Erro: o campo de confirmação da nova senha está vazio!';
translations['pt-br']['Error: new password and confirmed one don\'t match!'] = 'Erro: nova senha e uma não coincide confirmada!';
translations['pt-br']['Error: cannot parse full username due to invalid character'] = 'Erro: não é possível analisar o nome de usuário completo devido a um caractere inválido';
translations['pt-br']['Error: invalid character in username provided'] = 'Erro: caractere inválido no nome de usuário fornecido';

translations['pt-br']['Error: The user does not have access to the requested information.'] = 'Erro: O usuário não tem acesso às informações solicitadas.';
translations['pt-br']['Error: The user has entered an invalid password.'] = 'Erro: o usuário inseriu uma senha inválida.';
translations['pt-br']['Error: The computer name is invalid.'] = 'Erro: o nome do computador é inválido.';
translations['pt-br']['Error: The operation is allowed only on the primary domain controller of the domain.'] = 'Erro: a operação é permitida apenas no controlador de domínio primário do domínio.';
translations['pt-br']['Error: The user name could not be found.'] = 'Erro: o nome de usuário não foi encontrado.';
translations['pt-br']['Error: The password doesn\'t meet with the current password policy requirement.'] = 'Erro: a senha não atende ao requisito da política de senha atual.';
translations['pt-br']['Error: Cannot access to specified domain'] = 'Erro: Não é possível acessar o domínio especificado';
translations['pt-br']['An internal error occured'] = 'Ocorreu um erro interno';

translations['pt-br']['Windows password changed! Please retry connecting with your new password.'] = 'Senha do Windows alterada! Tente conectar-se novamente com sua nova senha.';

translations['pt-br']['Admin not allowed to connect via the web portal'] = 'O administrador não tem permissão para se conectar através do portal da web';